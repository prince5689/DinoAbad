/* ===== Content data (edit here) ===== */
const skills = [
  { title: 'Programming', icon: 'fa-code', items: [['HTML5', 90], ['CSS3', 85], ['JavaScript', 80], ['Java', 75], ['PHP', 75], ['Python', 70], ['SQL', 80]] },
  { title: 'Frameworks', icon: 'fa-layer-group', items: [['Bootstrap', 85], ['React (Learning)', 45]] },
  { title: 'Database', icon: 'fa-database', items: [['MySQL', 85], ['Firebase', 65]] },
  { title: 'Tools', icon: 'fa-screwdriver-wrench', items: [['Git', 75], ['GitHub', 80], ['VS Code', 90], ['XAMPP', 85], ['Figma', 65]] },
  { title: 'Networking', icon: 'fa-network-wired', items: [['Cisco', 75], ['MikroTik', 70], ['Network Design', 75]] },
];
const projects = [
  { name: 'Smart Food Ordering System', icon: 'fa-utensils', desc: 'A smart ordering platform that lets customers browse menus and place orders quickly.', tech: ['PHP', 'MySQL', 'JavaScript'] },
  { name: 'Restaurant Ordering and Management System', icon: 'fa-store', desc: 'End-to-end system for managing orders, menu items, staff and sales reports.', tech: ['PHP', 'MySQL', 'Bootstrap'] },
  { name: 'Computer Laboratory Equipment Usage Monitoring System', icon: 'fa-desktop', desc: 'Tracks equipment usage and schedules across computer laboratories.', tech: ['Java', 'MySQL'] },
  { name: 'Cash Shortage Prevention System', icon: 'fa-money-bill-trend-up', desc: 'Monitors cash flow records to detect and help prevent shortages.', tech: ['PHP', 'MySQL', 'JavaScript'] },
  { name: 'Computer Registration System', icon: 'fa-clipboard-user', desc: 'Registers and manages computer units and user records in one dashboard.', tech: ['Java', 'SQL'] },
];
const services = [
  ['fa-globe', 'Web Development'], ['fa-laptop-code', 'Software Development'], ['fa-database', 'Database Design'],
  ['fa-ethernet', 'Network Setup'], ['fa-gears', 'System Development'], ['fa-pen-ruler', 'UI/UX Design'],
];
const certs = [
  ['fa-code', 'Programming'], ['fa-network-wired', 'Networking'], ['fa-diagram-project', 'Software Engineering'],
  ['fa-server', 'Database Management'], ['fa-shield-halved', 'Cybersecurity'],
];
const timeline = [
  ['Education', 'Bachelor of Science in Information Technology'], ['Learning', 'Learning Programming'],
  ['Building', 'Creating Software Projects'], ['Infrastructure', 'Networking'], ['Web', 'Web Development'],
];
const stats = [['5+', 'Projects Completed'], ['6+', 'Programming Languages'], ['3+', 'Years Learning Experience']];

/* ===== Helpers ===== */
const $ = (id) => document.getElementById(id);
const render = (id, list, tpl) => { $(id).innerHTML = list.map(tpl).join(''); };

/* ===== Render sections ===== */
function renderContent() {
  render('stats', stats, ([n, l]) => `<div class="col-4 stat"><b data-count="${parseInt(n)}">0</b>+<br><small>${l}</small></div>`);
  render('skills-grid', skills, (s, i) => `
    <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="${i * 80}">
      <div class="glass skill-card hover-lift"><h3><i class="fa-solid ${s.icon}"></i>${s.title}</h3>
      ${s.items.map(([n, p]) => `<div class="skill-row"><div class="d-flex justify-content-between"><span>${n}</span><span>${p}%</span></div><div class="bar"><i data-w="${p}"></i></div></div>`).join('')}
      </div></div>`);
  render('projects-grid', projects, (p, i) => `
    <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="${i * 80}">
      <article class="glass project hover-lift">
        <div class="thumb-wrap"><div class="thumb" role="img" aria-label="${p.name} screenshot placeholder"><i class="fa-solid ${p.icon}"></i></div></div>
        <div class="body"><h3>${p.name}</h3><p>${p.desc}</p>
        <div>${p.tech.map((t) => `<span class="tag">${t}</span>`).join('')}</div>
        <div class="d-flex gap-2 mt-2"><a class="btn-neon outline" href="https://github.com/" target="_blank" rel="noopener"><i class="fa-brands fa-github"></i> GitHub</a>
        <a class="btn-neon" href="#" target="_blank" rel="noopener"><i class="fa-solid fa-arrow-up-right-from-square"></i> Live Demo</a></div></div>
      </article></div>`);
  render('services-grid', services, ([ic, t], i) => `
    <div class="col-6 col-lg-4" data-aos="zoom-in" data-aos-delay="${i * 60}"><div class="glass card-icon hover-lift"><i class="fa-solid ${ic}"></i><h3>${t}</h3></div></div>`);
  render('certs-grid', certs, ([ic, t], i) => `
    <div class="col-6 col-lg-4" data-aos="flip-left" data-aos-delay="${i * 60}"><div class="glass card-icon hover-lift"><i class="fa-solid ${ic}"></i><h3>${t}</h3><p>Certificate of Completion</p></div></div>`);
  render('timeline-list', timeline, ([k, t]) => `<li class="glass" data-aos="fade-up"><small>${k}</small><h3 class="h6 m-0">${t}</h3></li>`);
}

/* ===== Animated counters + skill bars (on scroll into view) ===== */
function observeReveal() {
  const io = new IntersectionObserver((entries) => entries.forEach((e) => {
    if (!e.isIntersecting) return;
    e.target.querySelectorAll('[data-w]').forEach((b) => (b.style.width = b.dataset.w + '%'));
    e.target.querySelectorAll('[data-count]').forEach((c) => {
      const end = +c.dataset.count; let n = 0;
      const t = setInterval(() => { c.textContent = ++n; if (n >= end) clearInterval(t); }, 180);
    });
    io.unobserve(e.target);
  }), { threshold: 0.3 });
  document.querySelectorAll('#skills, #about').forEach((s) => io.observe(s));
}

/* ===== Visual effects ===== */
function initEffects() {
  AOS.init({ duration: 800, once: true });
  new Typed('#typed', { strings: ['HTML', 'CSS', 'JavaScript', 'Java', 'PHP', 'MySQL', 'Networking', 'Software Engineering'], typeSpeed: 70, backSpeed: 40, backDelay: 1200, loop: true });
  particlesJS('particles-js', {
    particles: { number: { value: 55 }, color: { value: '#00e5ff' }, opacity: { value: 0.45 }, size: { value: 3 },
      line_linked: { enable: true, color: '#3b6cff', opacity: 0.3 }, move: { enable: true, speed: 1.4 } },
    interactivity: { events: { onhover: { enable: true, mode: 'grab' } } },
  });
  const glow = $('cursor-glow');
  window.addEventListener('mousemove', (e) => { glow.style.left = e.clientX + 'px'; glow.style.top = e.clientY + 'px'; });
  // Parallax on the hero illustration
  window.addEventListener('scroll', () => { document.querySelector('.hero-art').style.marginTop = window.scrollY * 0.08 + 'px'; }, { passive: true });
  // Ripple effect on buttons
  document.addEventListener('click', (e) => {
    const b = e.target.closest('.btn-neon'); if (!b) return;
    const r = b.getBoundingClientRect(), s = Math.max(r.width, r.height), el = document.createElement('span');
    el.className = 'ripple'; el.style.cssText = `width:${s}px;height:${s}px;left:${e.clientX - r.left - s / 2}px;top:${e.clientY - r.top - s / 2}px`;
    b.appendChild(el); setTimeout(() => el.remove(), 600);
  });
  // Highlight active nav link
  const links = [...document.querySelectorAll('.nav-link')];
  window.addEventListener('scroll', () => {
    let cur = 'home';
    document.querySelectorAll('section[id]').forEach((s) => { if (window.scrollY >= s.offsetTop - 140) cur = s.id; });
    links.forEach((a) => a.classList.toggle('active', a.getAttribute('href') === '#' + cur));
  }, { passive: true });
  // Close mobile menu after choosing a link
  links.forEach((a) => a.addEventListener('click', () => bootstrap.Collapse.getInstance($('menu'))?.hide()));
}

/* ===== Contact form (opens the visitor's email app; swap for Formspree/EmailJS if desired) ===== */
function initForm() {
  $('contact-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const v = (id) => $(id).value.trim();
    if (!v('name') || !/^\S+@\S+\.\S+$/.test(v('email')) || !v('subject') || !v('message')) { $('form-status').textContent = 'Please complete all fields with a valid email.'; return; }
    const body = encodeURIComponent(`${v('message')}\n\n- ${v('name')} (${v('email')})`);
    location.href = `mailto:you@example.com?subject=${encodeURIComponent(v('subject'))}&body=${body}`;
    $('form-status').textContent = 'Thanks! Opening your email app...';
  });
}

/* ===== Init ===== */
document.addEventListener('DOMContentLoaded', () => {
  renderContent(); initEffects(); initForm(); observeReveal();
});
window.addEventListener('load', () => setTimeout(() => $('loader').classList.add('done'), 600));
