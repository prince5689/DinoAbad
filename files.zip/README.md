# Dino Abungan - Portfolio

Futuristic dark-mode portfolio: glassmorphism, neon cyan/blue, particles, AOS, Typed.js.

## Run
Open `index.html` in a browser (internet needed for the CDN libraries), or serve the folder with VS Code Live Server / XAMPP.

## Customize
- **Content** (skills, projects, services, certificates, timeline, stats): edit the data arrays at the top of `js/script.js`.
- **Profile photo:** put `images/profile.jpg` and replace the `.avatar` icon in `index.html` with `<img src="images/profile.jpg" alt="Dino Abungan">`.
- **Project screenshots:** add images to `images/` and swap the `.thumb` block in `js/script.js` for `<img>` tags.
- **Links:** replace the GitHub / Live Demo URLs, social links, email and phone placeholders.
- **Resume:** save your file as `assets/resume.pdf`.
- **Map:** replace the placeholder in the Contact section with a Google Maps embed.
- **Colors:** change the CSS variables at the top of `css/style.css`.

## Structure
```
portfolio/
  index.html
  css/style.css
  js/script.js
  images/
  assets/
  README.md
```
